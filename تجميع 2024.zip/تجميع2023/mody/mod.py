from pyrogram import Client
from pyrogram import filters

from mody.Redis import db
from mody.get_info import token, sudo_info, get_bot

Bot = Client(
    'eeeerubot',
    29478176,
    '5d778e6b854621db6316c224767d0402',
    bot_token=token,
    plugins=dict(root='plugins/bot')
)


sudo_client = Client(
    'ttXvw',
    29478176,
    '5d778e6b854621db6316c224767d0402',
    session_string=db.get(f'{get_bot.id}:{sudo_info.id}:session'),
    plugins=dict(root='plugins/user')
)
sudo_client.login = False


def Bfilter(text):
    return filters.msg(text) & filters.private & filters.user(sudo_info.id)

